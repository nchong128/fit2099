public class LairDriver {
    public static void main(String[] args) {
        Lair myLair = new Lair();
        myLair.printStatus();
    }
}
